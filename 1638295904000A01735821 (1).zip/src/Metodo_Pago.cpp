/*Esta es la declaracion de la clase Metodo_Pago. Incluye la clase Metodo_Pago para su compisicion. Autores:
Bernardo de la Sierra Rábago Matricula A01735821, Angel Estrada Centeno A01732584, Cruz Daniel Perez Jimenez
A01736214. Fecha de creacion: 26/11/2021*/
//Esta clase te da los nombres del usuario,vendedor y objetos con sus respectivos metodos y atributos
#include"Metodo_Pago.h"
#include <string>
using namespace std;
//Constructores
Metodo_Pago::Metodo_Pago (string nombreusuario1,string dirusuario1,string  telusuario1,string destinatario1,
string dirdes1, string  teldestinatario1,string compra1, string  importe1,string dia1,string mes1,
string anio1,string correous1,string correodes1){
    Metodo_Pago::setnombreUs (nombreusuario1);
    Metodo_Pago::setcorreodes (correodes1);
    Metodo_Pago::setcorreous (correous1);
    Metodo_Pago::setdirUs (dirusuario1);
    Metodo_Pago::settelUs (telusuario1);
    Metodo_Pago::setdestinatario (destinatario1);
    Metodo_Pago::setdirdes (dirdes1);
    Metodo_Pago::seteldes (teldestinatario1);
    Metodo_Pago::setcompra (compra1);
    Metodo_Pago::setimporte (importe1);
    Metodo_Pago::setdia (dia1);
    Metodo_Pago::setmes (mes1);
    Metodo_Pago::setanio (anio1);
}

Metodo_Pago::Metodo_Pago (){
    nombreusuario = " ";
    dirusuario = " ";
    telusuario = " ";
    destinatario = " ";
    dirdes = " ";
    teldestinatario = " ";
    compra = " ";
    importe = " ";
    dia = " ";
    mes = " ";
    anio = " ";
    correodes = " ";
    correous = " ";
}
//Setters
void Metodo_Pago::setnombreUs (string nombreusuario1){
   nombreusuario = nombreusuario1; 
}

void Metodo_Pago::setdirUs (string dirusuario1){
    dirusuario = dirusuario1;
}

void Metodo_Pago::settelUs (string telusuario1){
    telusuario = telusuario1;
}

void Metodo_Pago::setdestinatario (string destinatario1){
    destinatario = destinatario1;
}

void Metodo_Pago::setdirdes (string dirdes1){
    dirdes = dirdes1;
}

void Metodo_Pago::seteldes (string  teldestinatario1){
    teldestinatario = teldestinatario1;
}

void Metodo_Pago::setcompra (string compra1){
    compra = compra1;
}

void Metodo_Pago::setimporte (string  importe1){
    importe = importe1;
}

void Metodo_Pago::setdia (string dia1){
    dia = dia1;
}

void Metodo_Pago::setmes (string mes1){
    mes = mes1;
}

void Metodo_Pago::setanio (string anio1){
    anio = anio1;
}

void Metodo_Pago::setcorreous (string correous1){
    correous = correous1;
}

void Metodo_Pago::setcorreodes (string correodes1){
    correodes = correodes1;
}
//Getters
string Metodo_Pago::getcorreous (){
    return correous;
}

string Metodo_Pago::getcorreodes (){
    return correodes;
}

string Metodo_Pago::getInfoUs(){
    return "\n***COMPRADOR***\nNombre del comprador: "+ nombreusuario+"\nDireccion del comprador: "+dirusuario+"\nTelefono del comprador: "+ telusuario+"\nCorreo del comprador: "+correous+"\n";
}
string Metodo_Pago::getInfoDes(){
    return "\n***VENDEDOR***\nNombre del remitente: "+destinatario+"\nDireccion del vendedor: "+ dirdes +"\nTelefono de: "+ teldestinatario+"\nCorreo del vendedor: "+correodes+"\n";
}
string Metodo_Pago::getCompra(){
    return "Fecha de la compra: "+dia+"/"+mes+"/"+ anio+"\n***COMPRA***\nEl producto o servicio adquirido es: "+ compra+"\nPrecio del producto o servicio: $"+importe+"\n";
}
string Metodo_Pago::getfecha(){
    return dia+"/"+mes+"/"+ anio+" ";
}
string Metodo_Pago::getmonto(){
    return importe;
}