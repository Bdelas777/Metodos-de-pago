/*Esta es la declaracion de la clase Tarjeta. Incluye la clase Tarjeta para su compisicion.
Autores: Bernardo de la Sierra Rábago Matricula A01735821, Angel Estrada Centeno A01732584, 
Cruz Daniel Perez Jimenez A01736214. Fecha de creacion: 26/11/2021*/
#include "Tarjeta.h"
using namespace std;
//Constructor
Tarjeta::Tarjeta (Metodo_Pago info3,string numerotarjeta1,string acaducidad1,string mcaducidad1,string cvv1){
    datos3=info3;
    Tarjeta::setnumtarj (numerotarjeta1);
    Tarjeta::setmcad (mcaducidad1);
    Tarjeta::setacad (acaducidad1);
    Tarjeta::setcvv (cvv1);
}
//Setters
void Tarjeta::setnumtarj (string numerotarjeta1){
    numerotarjeta=numerotarjeta1;
}

void Tarjeta::setmcad (string mcaducidad1){
    mcaducidad=mcaducidad1;
}

void Tarjeta::setacad (string acaducidad1){
    acaducidad=acaducidad1;
}

void Tarjeta::setcvv (string cvv1){
    cvv=cvv1;
}
//Getters
string Tarjeta::getmcad (){
    return mcaducidad;
}

string Tarjeta::getacad (){
    return acaducidad;
}

string Tarjeta::getnumtar (){
    return numerotarjeta;
}