/*Seccion principal del programa. Dependiendo de la seleccion
que haga el usuario se llamarán ciertas clases con sus respectivos 
componentes. Autores: Bernardo de la Sierra Rábago Matricula A01735821, Angel Estrada Centeno A01732584, Cruz Daniel Perez Jimenez A01736214. Fecha de creacion: 28/11/2021*/
//Se definen las librerias a ocupar
#include<iostream>
#include<fstream>
#include<unistd.h>
#include<string>
#include"Transferencia.cpp"
using namespace std;

//Se declaran las variables a ocupar con su respectivo tipo
string contra;
string nombreusuaario1;
string dirusuario1;
string telusuario1;
string destinatario1;
string dirdes1;
string teldestinatario1;
string compra1;
string importe1; 
string dia1; 
string mes1;
string correous1;
string correodes1;
string anio1;
string rfc1; 
string banco1;
string referencia1;
string cuenta1;
string clave1;
string comision1;

//Se inicia el ciclo repetitivo del menu, solo se cierra si el usuario asi lo desea
int main (  ) {
  bool a = true;
  bool b = false;
  bool c = true;
  bool d = false;
  int opc = 0;
  cout << "***BIENVENIDO/A***\n¿Que desea realizar?\n1.Iniciar sesion\n2.Salir" << endl;
  cin >> opc;
  if ( opc==1 ){
  cin.ignore (  );
    while ( a == true ){
      system ( "clear" );
      cout << "***INICIO DE SESION***" << endl;
      cout << "Correo:" << endl;
      getline ( cin,correous1 );
      cout << "Clave:" << endl;
      getline ( cin,contra );
      if  (  ( correous1=="Prueba@gmail.com" and contra=="1234" )or ( correous1=="DanPerez@gmail.com" and contra=="BestTeacherEver" ) ){
        a=false;
        system ( "clear" );
        while ( b == false ){
        cout << "Bienvenido\n¿Que desea realizar?\n1.Realizar una compra.\n2.Cerrar sesion." << endl;
        cin >> opc;
        if ( opc==1 ){//Se llenan los datos del usuario, vendedor y compra para la transaccion
          cin.ignore (  );
          system ( "clear" );
          b=true;
          cout << "***COMPRA EN LINEA***" << endl;
          cout << "COMPRADOR" << endl;
          cout << "Bienvenido, antes de comenzar, introduzca los datos que se piden a continuacion." << endl;
          cout << "Introduzca su nombre completo: " << endl;
          getline ( cin,nombreusuaario1 );
          cout << "Introduzca su numero de telefono: " << endl;
          getline ( cin,telusuario1 );
          cout << "Introduzca la direccion a la que la compra llegara: " << endl;
          getline ( cin,dirusuario1 );
          cout << "Introduzca su correo electronico:" << endl;
          getline ( cin,correous1 );
          system ( "clear" );
          cout << "***COMPRA EN LINEA***" << endl;
          cout << "VENDEDOR" << endl;
          cout << "Introduzca los datos del vendedor que se piden a continuacion. " << endl;
          cout << "Introduzca el nombre completo: " << endl;
          getline ( cin,destinatario1 );
          cout << "Introduzca su numero de telefono: " << endl;
          getline ( cin,teldestinatario1 );
          cout << "Introduzca la direccion de la que la compra saldra: " << endl;
          getline ( cin,dirdes1 );
          cout << "Introduzca el correo electronico del vendedor: " << endl;
          getline ( cin,correodes1 );
          system ( "clear" );
          cout << "***COMPRA EN LINEA***" << endl;
          cout << "COMPRA" << endl;
          cout << "Introduzca el dia de la compra:" << endl;
          getline ( cin,dia1 );
          cout << "Introduzca el mes de la compra:" << endl;
          getline ( cin,mes1 );
          cout << "Introduzca el anio de la compra:" << endl;
          getline ( cin,anio1 );
          cout << "Introduzca el objeto/servicio adquirido:" << endl;
          getline ( cin,compra1 );
          cout << "Introduzca el precio del objeto/servicio adquirido:" << endl;
          getline ( cin,importe1 );
          system ( "clear" );
          Metodo_Pago usuario1 ( nombreusuaario1,dirusuario1,telusuario1,destinatario1,dirdes1,
          teldestinatario1,compra1,importe1,dia1,mes1,anio1,correous1,correodes1 );
          //Se decide que tipo de metodo de pago se utiliara, y se llama a la respectiva clase
          while ( c == true ){
            system ( "clear" );
            cout << "***METODO DE PAGO***" << endl;
            cout << "¿Que metodo de pago utilizara?\n1.Deposito bancario\n2.Tarjeta de debito/credito\n3.Transferencia electronica\n4.Ver datos de la compra." << endl;
            cin >> opc;
            cin.ignore (  );
            system ( "clear" );
            if ( opc == 1 ){
              while ( d == false ){
                c = false;
                cout << "***DEPOSITO BANCARIO***" << endl;/*Se llama a la clase Deposito y sus respectivos metodos y atributos
                Incluye casos de prueba */
                cout << "Antes de continuar, introduzca la informacion que se le pide" << endl;
                cout << "Introduzca su rfc: " << endl;
                getline ( cin,rfc1 );
                cout << "Introduzca su clabe: " << endl;
                getline ( cin,clave1 );
                cout << "Introduzca el banco a depositar: " << endl;
                getline ( cin,banco1 );
                cout << "Introduzca el numero de referencia: " << endl;
                getline ( cin,referencia1 );
                cout << "Introduzca el numero de cuenta a depositar: " << endl;
                getline ( cin,cuenta1 );
                Deposito usuariodeposito1  ( Metodo_Pago ( nombreusuaario1,dirusuario1,telusuario1,destinatario1,dirdes1,
                teldestinatario1,compra1,importe1,dia1,mes1,correous1,correodes1,anio1 ),banco1,referencia1,cuenta1,
                clave1,rfc1 );
                cout << "\nLos datos bancarios son: \n" << usuariodeposito1.getDatosBancarios (  ) << "\n";
                cout << "El monto a liquidar es: $" << usuario1.getmonto (  ) << endl;
                cout << "¿Cuantos depositos desea realizar?\n";
                int num_deposito;
                cin >> num_deposito;
                double guardadeposito[1000],numero[1000],comprobante = 0;
                for  ( int i = 0; i < num_deposito; i++ ){
                  numero[i]=i+1;
                  cout << "Introduzca el monto del deposito " << numero[i] << " :" << endl;;
                  cin >> guardadeposito[i];
                  comprobante+=guardadeposito[i];
                  if ( comprobante > stod ( usuario1.getmonto (  ) ) ){
                    cout << "Este deposito excede el monto total de la compra.\nIntroduzca otro monto:" << endl;
                    comprobante-=guardadeposito[i];
                    cin >> guardadeposito[i];
                  }
                }
                if ( comprobante < stod ( usuario1.getmonto (  ) ) ){
                    cout << "El deposito no liquida la compra, generaras una deuda!" << endl;
                  }
                cout << "Los depositos realizados son:\n";
                for  ( int i = 0; i < num_deposito; i++ ){
                  cout << "El deposito numero " << numero[i] << " con un monto de $" << guardadeposito[i] << "\n";
                }
                cout << "¿Desea cancelar algún deposito? Si/No \n";
                string respuesta;
                cin >> respuesta;
                if ( respuesta == "si" or respuesta == "Si" or respuesta == "SI" ){
                  cout << "Introduzca el numero de deposito a cancelar: \n";
                  int depo_eliminar;
                  cin >> depo_eliminar;
                  for  ( int i = depo_eliminar-1; i < num_deposito; i++ )
                  {
                    guardadeposito[i]=guardadeposito[i+1];
                  }
                num_deposito--;
                cout << "Los depositos actualizados son los siguientes: \n";
                for  ( int i = 0; i < num_deposito; i++ ){
                  cout << "El deposito numero " << numero[i] << " con un monto de $" << guardadeposito[i] << "\n";
                }
                }
                cout << "Los depositos realizados son:\n";
                for  ( int i = 0; i < num_deposito; i++ ){
                  cout << "El deposito numero " << numero[i] << " con un monto de $" << guardadeposito[i] << "\n";
                }
                cout  <<  "***TRANSACCION REALIZADA CORRECTAMENTE***"  <<  endl;
                cout  <<  "Requiere un ticket? si/no\n";
                cin  >>  respuesta;
                if ( respuesta=="si" or respuesta=="Si" or respuesta=="SI" ){
                  ofstream ticket;
                  ticket.open ( "Ticket.txt", ios::out );
                  ticket << "***TICKET DE COMPRA***" << endl;
                  ticket << usuario1.getCompra (  ) << endl;
                  ticket << usuariodeposito1.getDatosBancarios (  );
                  ticket << usuario1.getInfoDes (  ) << endl;
                  ticket << "Los depositos realizados son los siguientes:\n" << endl;
                  for ( int i=0;i<num_deposito;i++ ){
                    ticket << "El deposito numero " << numero[i] << " es de un monto de: $" << guardadeposito[i] << endl;
                  }
                  ticket << "Monto a pagar: $"<<usuario1.getmonto()<<endl;;
                  ticket << "Monto pagado: $"<<comprobante<<endl;
                  ticket << "***GRACIAS POR SU COMPRA***" << endl;
                  d=true;
                  cout << "Ticket creado." << endl;
                  cout << "Gracias por haber utilizado este programa." << endl;
                  cout << "Programa realizado por Bernardo de la Sierra, Cruz Daniel Perez y Angel Estrada" << endl;
                }else if ( respuesta == "no" or respuesta == "No" or respuesta == "NO" ){
                  d=true;
                  cout << "Gracias por haber utilizado este programa." << endl;
                  cout << "Programa realizado por Bernardo de la Sierra, Cruz Daniel Perez y Angel Estrada" << endl;
                }
              }
            }else if ( opc==2 ){
              c=false;
              string numerotarjeta1,acaducidad1,mcaducidad1,cvv1,respuesta;
              while ( d==false ){/*Se llama a la clase Tarjeta y sus respectivos metodos y atributos
                Incluye casos de prueba */
                cout << "***TARJETA DE CREDITO/DEBITO***" << endl;
                cout << "Introduzca lo que se pide a continuacion." << endl;
                cout << "Introduzca el numero de tarjeta:" << endl;
                getline ( cin,numerotarjeta1 );
                if ( numerotarjeta1.size (  )<16 ){
                  cout << "El numero de tarjeta debe estar conformada por 16 digitos." << endl;
                  getline ( cin,numerotarjeta1 );
                }
                cout << "Introduzca el mes en el que vence:" << endl,
                getline ( cin,mcaducidad1 );
                cout << "Introduzca el anio en el que vence:" << endl;
                getline ( cin,acaducidad1 );
                cout << "Introduzca el CVV de la tarjeta:" << endl;
                getline ( cin,cvv1 );
                Tarjeta usuariotar1 ( Metodo_Pago ( nombreusuaario1,dirusuario1,telusuario1,destinatario1,dirdes1,
                teldestinatario1,compra1,importe1,dia1,mes1,correous1,correodes1,anio1 ),numerotarjeta1,acaducidad1,mcaducidad1,cvv1 );
                system ( "clear" );
                cout << "***TARJETA DE CREDITO/DEBITO***" << endl;
                cout << "Los datos bancarios son los siguientes: " << endl;
                cout << "Tarjeta con terminacion: "+usuariotar1.getnumtar (  )+"\nMes y anio de vencimiento: "+usuariotar1.getmcad (  )+"/"+usuariotar1.getacad (  ) << endl;
                cout << "***TRANSACCION REALIZADA CORRECTAMENTE***" << endl;
                cout  <<  "Requiere un ticket? si/no\n";
                  cin  >>  respuesta;
                  if ( respuesta=="si" or respuesta=="Si" or respuesta=="SI" ){
                    ofstream ticket;
                    ticket.open ( "Ticket.txt", ios::out );
                    ticket << "***TICKET DE COMPRA***" << endl;
                    ticket << usuario1.getCompra (  ) << endl;
                    ticket << "***TARJETA DE CREDITO/DEBITO***\n" << endl;
                    ticket << "Tarjeta con terminacion: "+usuariotar1.getnumtar (  )+"\nMes y anio de vencimiento: "+usuariotar1.getmcad (  )+"/"+usuariotar1.getacad (  ) << endl;;
                    ticket << usuario1.getInfoDes (  ) << endl;
                    ticket << "Monto pagado: $"+usuario1.getmonto (  );
                    ticket << "***GRACIAS POR SU COMPRA***" << endl;
                    d=true;
                    cout << "Ticket realizado" << endl;
                    cout << "Gracias por haber utilizado este programa." << endl;
                    cout << "Programa realizado por Bernardo de la Sierra, Cruz Daniel Perez y Angel Estrada" << endl;
                  }else if ( respuesta == "no" or respuesta == "No" or respuesta == "NO" ){
                    d=true;
                    cout << "Gracias por haber utilizado este programa." << endl;
                    cout << "Programa realizado por Bernardo de la Sierra, Cruz Daniel Perez y Angel Estrada" << endl;
                  }
              }
            }else if ( opc == 3 ){
              while ( d == false ){/*Se llama a la clase Transferencia y sus respectivos metodos y atributos
                Incluye casos de prueba */
                c = false;
                cout << "***TRANSFERENCIA ELECTRONICA***" << endl;
                cout << "Antes de continuar, introduzca la informacion que se le pide." << endl;
                cout << "Introduzca el banco a tranferir:" << endl;
                getline ( cin,banco1 );
                cout << "Introduzca el numero de referencia a transferir:" << endl;
                getline ( cin,referencia1 );
                cout << "Introduzca su numero de cuenta:" << endl;
                getline ( cin,cuenta1 );
                cout << "Introduzca su numero de clabe:" << endl;
                getline ( cin,clave1 );
                cout << "Introduzca el monto de la comision:" << endl;
                getline ( cin,comision1 );
                Transferencia usuariotransfer1 ( Metodo_Pago ( nombreusuaario1,dirusuario1,telusuario1,destinatario1,dirdes1,
                teldestinatario1,compra1,importe1,dia1,mes1,correous1,correodes1,anio1 ),banco1,referencia1,cuenta1,
                clave1,comision1 );
                double montoo = 0;
                double comisionn = 0;
                montoo = stod ( usuario1.getmonto (  ) );
                comisionn = stod ( usuariotransfer1.getcomision (  ) );
                cout << "\nLos datos bancarios son: \n" << usuariotransfer1.getDatosBancarios (  ) << "\n";
                cout << "El monto a liquidar es: $" << to_string ( montoo+comisionn ) << endl;
                cout << "¿Cuantas transferencias desea realizar?\n";
                int num_trans;
                cin >> num_trans;
                int guardatrans[1000],numero[1000],comprobante=0;
                for  ( int i = 0; i < num_trans; i++ ){
                  numero[i]=i+1;
                    cout << "Introduzca el monto a transferir " << numero[i] << " :" << endl;;
                    cin >> guardatrans[i];
                    comprobante+=guardatrans[i];
                    if ( comprobante >  ( montoo+comisionn ) ){
                      cout << "Esta transferencia excede el monto total de la compra.\nIntroduzca otro monto:" 
                      << endl;
                      comprobante-=guardatrans[i];
                      cin >> guardatrans[i];
                    }
                  } 
                  if ( comprobante <  ( montoo+comisionn ) ){
                      cout << "Esta transferencia no liquida la compra, generaras una deuda!" << endl;
                    }
                cout << "Las transferencas realizadas son:\n";
                for  ( int i = 0; i < num_trans; i++ ){
                  cout << "La transferencia numero " << numero[i] << " tiene un monto de: $" << guardatrans[i] 
                  << "\n";
                }
                cout << "¿Desea cancelar alguna transferencia? Si/No \n";
                  string respuesta;
                  cin >> respuesta;
                  if ( respuesta=="si" or respuesta=="Si" or respuesta=="SI" ){
                    cout << "Introduzca el numero de transferencia a cancelar: \n";
                    int depo_eliminar;
                    cin >> depo_eliminar;
                    for  ( int i = depo_eliminar-1; i < num_trans; i++ )
                    {
                      guardatrans[i]=guardatrans[i+1];
                    }
                    num_trans--;
                    cout << "Las transferencias actualizados son los siguientes: \n";
                    for  ( int i = 0; i < num_trans; i++ ){
                      cout << "La transferencia numero " << numero[i] << " tiene un monto de $"
                       << guardatrans[i] << "\n";
                    }
                  }
                  cout << "Las transferencias realizadas son:\n";
                  for  ( int i = 0; i < num_trans; i++ ){
                    cout << "La transferencia numero " << numero[i] << " tiene un monto de $" 
                    << guardatrans[i] << "\n";
                  }
                  cout  <<  "***TRANSACCION REALIZADA CORRECTAMENTE***"  <<  endl;
                  cout  <<  "Requiere un ticket? si/no\n";
                  cin  >>  respuesta;
                  if ( respuesta=="si" or respuesta=="Si" or respuesta=="SI" ){
                    ofstream ticket;
                    ticket.open ( "Ticket.txt", ios::out );
                    ticket << "***TICKET DE COMPRA***" << endl;
                    ticket << usuario1.getCompra (  ) << endl;
                    ticket << usuariotransfer1.getDatosBancarios (  );
                    ticket << usuario1.getInfoDes (  ) << endl;
                    ticket << "Las transferencias realizadas son las siguientes:\n" << endl;
                    for ( int i=0;i<num_trans;i++ ){
                      ticket << "La transferencia numero " << numero[i] << " tiene un monto de: $" 
                      << guardatrans[i] << endl;
                    }
                    ticket << "Monto a pagar: $"<<usuario1.getmonto()<<endl;;
                    ticket << "Monto pagado: $"<<comprobante<<endl;
                    ticket << "***GRACIAS POR SU COMPRA***" << endl;
                    d=true;
                    cout << "Ticket realizado" << endl;
                    cout << "Gracias por haber utilizado este programa." << endl;
                    cout << "Programa realizado por Bernardo de la Sierra, Cruz Daniel Perez y Angel Estrada" 
                    << endl;
                  }else if ( respuesta == "no" or respuesta == "No" or respuesta == "NO" ){
                    d=true;
                    cout << "Gracias por haber utilizado este programa." << endl;
                    cout << "Programa realizado por Bernardo de la Sierra, Cruz Daniel Perez y Angel Estrada" 
                    << endl;
                  }
              }
            }else   if ( opc==4 ){//Se despliega la cuarta opcion del menu que resume el pedido
              cout << usuario1.getCompra (  );
              cout << usuario1.getInfoUs (  );
              cout << usuario1.getInfoDes (  );
              cout << "introduzca cualquier numero para regresar" << endl;
              cin >> opc;
              if ( opc==1 ){
                c=true;
                cin.ignore (  );
              }
              }else{
                cout << "Ese metodo de pago no se encuentra registrado, intentelo de nuevo." << endl;
                sleep ( 2 );
              }
          }
        }else if ( opc==2 ){
          cout << "Gracias por usar este programa." << endl;
          cout << "Programa realizado por Bernardo de la Sierra, Cruz Daniel Perez y Angel Estrada" << endl;
          b=true;
        }else{
          system ( "clear" );
          cout << "Introduzca una opcion valida.";
          sleep ( 2 );
        }
        }
      } else{
        system ( "clear" );
        cout << "El correo y/o la clave son incorrectos.\n" << endl;
        sleep ( 2 );
      }
    }
  }
    else if ( opc==2 ){
      cout << "Programa realizado por Bernardo de la Sierra, Cruz Daniel Perez y Angel Estrada." << endl;
      cout << "Gracias por usar este programa" << endl;
      a=false;
    }
    else{
      system ( "clear" );
      cout << "Introduzca una opcion valida." << endl;
    }
  return 0;
} 