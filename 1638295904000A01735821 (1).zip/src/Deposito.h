/*Esta es la declaración de la clase Deposito e incluye la clase para tener la composición de sus métodos y 
atributos. Autores: Bernardo de la Sierra Rábago Matricula A01735821, Angel Estrada Centeno A01732584, Cruz
Daniel Perez Jimenez A01736214. Fecha de creacion: 26/11/2021*/
#include"Metodo_Pago.cpp"
//En esta clase adquirimos los atributos y métodos para hacer un deposito
class Deposito {
    private:
        //Atributos
        Metodo_Pago datos;
        string banco;
        string referencia;
        string cuenta;
        string clave;
        string rfc;
        //Métodos setters
        void setBanco (string banco1);
        void setReferencia (string referencia1);
        void setcuenta (string cuenta1);
        void setclabe (string clave1);
        void setRFC (string rfc1);
    public:
        //Constructor de clase Deposito
        Deposito (Metodo_Pago info,string banco1,string referencia1,string cuenta1,string clave1,string rfc1);
        //Métodos Getters
        string getDatosBancarios ();
        string getInfoDepo ();
};