/*Aquí se definen los metodos y atributos de clase tarjeta. Autores: Bernardo de la Sierra Rábago Matricula
A01735821, Angel Estrada Centeno A01732584, Cruz Daniel Perez Jimenez A01736214. Fecha de creacion: 
26/11/2021 */
#include "Deposito.cpp"
using namespace std;
class Tarjeta{
    private:
    //Atributos
    Metodo_Pago datos3;
    string mcaducidad;
    string acaducidad;
    string numerotarjeta;
    string cvv;
    //Setters
    void setnumtarj (string numerotarjeta1);
    void setmcad (string mcaducidad1);
    void setacad (string acaducidad1);
    void setcvv (string cvv1);
    public:
    //Constructor
    Tarjeta (Metodo_Pago info3,string numerotarjeta1,string acaducidad1,string mcaducidad1,string cvv1);
    //Getters
    string getmcad ();
    string getacad ();
    string getnumtar ();
};