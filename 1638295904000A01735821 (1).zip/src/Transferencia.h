/*Se definen los metodos y atributos de la clase Tarjeta. Autores: Bernardo de la Sierra Rábago Matricula
A01735821, Angel Estrada Centeno A01732584, Cruz Daniel Perez Jimenez A01736214. Fecha de creacion: 26/11/2021*/
//Se definen los metodos y atributos de la clase Transferencia
#include"Tarjeta.cpp"
class Transferencia{
    private:
        //Aributos
        Metodo_Pago datos2;
        string banco;
        string referencia;
        string cuenta;
        string clabe;
        string comision;
        //Setters
        void setBanco (string banco1);
        void setReferencia (string referencia1);
        void setcuenta (string cuenta1);
        void setclabe (string clabe1);
        void setcomision (string comision1);
    public:
        //Constructor
        Transferencia (Metodo_Pago info2,string banco1,string referencia1,string cuenta1,string clabe1,
        string comision);
        //Getters
        string getDatosBancarios ();
        string getcomision ();
};