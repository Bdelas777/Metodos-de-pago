//*Clase principal que hereda atributos y métodos. Autores: Bernardo de la Sierra Rábago Matricula A01735821,Angel Estrada Centeno A01732584, Cruz Daniel Perez Jimenez A01736214. Fecha de creacion: 26/11/2021 */
//Esta clase te da los nombres del usuario,vendedor y objetos con sus respectivos metodos y atributos
#include<string>
using namespace std;
class Metodo_Pago{
  private:
    //Atributos
    string nombreusuario;
    string dirusuario;
    string telusuario;
    string destinatario;
    string dirdes;
    string teldestinatario;
    string compra;
    string importe;
    string dia;
    string mes;
    string anio;
    string correous;
    string correodes;
    //Setters
    void setnombreUs (string nombreusuario1);
    void setdirUs (string dirusuario1);
    void settelUs (string  telusuario1);
    void setdestinatario (string destinatario1);
    void setdirdes (string dirdes1);
    void seteldes (string  teldestinatario1);
    void setcompra (string compra1);
    void setimporte (string  importe1);
    void setdia (string dia1);
    void setmes (string mes1);
    void setanio (string anio1);
    void setcorreous (string correous1);
    void setcorreodes (string correodes1);
  public:
    //Constructores
    Metodo_Pago ();
    Metodo_Pago (string nombreusuario1,string dirusuario1,string  telusuario1,string destinatario1,
    string dirdes1,string  teldestinatario1, string compra1, string  importe1,string dia1,string mes1,
    string anio1,string correous1,string correodes1);
    //Getters
    string getInfoUs ();
    string getInfoDes ();
    string getCompra ();
    string getfecha ();
    string getcorreous ();
    string getcorreodes ();
    string getmonto ();
};