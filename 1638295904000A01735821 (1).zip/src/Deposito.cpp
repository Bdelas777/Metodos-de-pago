#include"Deposito.h"
//En esta clase adquirimos los atributos y métodos para hacer un deposito
//Constructor
Deposito::Deposito (Metodo_Pago info,string banco1,string referencia1,string cuenta1,string clave1,string rfc1){
    datos=info;
    Deposito::setBanco (banco1);
    Deposito::setReferencia (referencia1);
    Deposito::setcuenta (cuenta1);
    Deposito::setclabe (clave1);
    Deposito::setRFC (rfc1);   
}
//Setters
void Deposito::setBanco (string banco1){
    banco = banco1;
}

void Deposito::setReferencia (string referencia1){
    referencia = referencia1;
}

void Deposito::setcuenta (string cuenta1){
    cuenta = cuenta1;
}

void Deposito::setclabe (string clave1){
    clave = clave1;
}

void  Deposito::setRFC (string rfc1){
    rfc = rfc1;
}
//Getters
string  Deposito::getDatosBancarios (){
    return "Su RFC  es: " + rfc + "\n su clabe es: " + clave + "\n el banco a depositar es: " + banco +
    "\n La referencia es: " + referencia + "\n su cuenta es: " + cuenta; 
}
string Deposito::getInfoDepo (){
    return datos.getCompra () + " hizo estos depositos el " + datos.getfecha () + "\n";
} 