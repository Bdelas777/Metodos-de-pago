/*Se definen los metodos y atributos de la clase Transferencia. Autores: Bernardo de la Sierra Rábago Matricula
 A01735821, Angel Estrada Centeno A01732584, Cruz Daniel Perez Jimenez A01736214. Fecha de creacion: 26/11/2021*/
//Se definen los metodos y atributos de la clase Transferencia
#include<string>
#include "Transferencia.h"
//Constructor
Transferencia::Transferencia(Metodo_Pago info2,string banco1,string referencia1,string cuenta1,
string clabe1,string comision1){
    datos2=info2;
    Transferencia::setBanco (banco1);
    Transferencia::setReferencia (referencia1);
    Transferencia::setcuenta (cuenta1);
    Transferencia::setclabe (clabe1);
    Transferencia::setcomision (comision1);
}
//Setters
void Transferencia::setBanco (string banco1){
    banco=banco1;
}

void Transferencia::setReferencia (string referencia1){
    referencia=referencia1;
}

void Transferencia::setcuenta (string cuenta1){
    cuenta=cuenta1;
}

void Transferencia::setclabe (string clabe1){
    clabe=clabe1;
}

void Transferencia::setcomision (string comision1){
    comision=comision1;
}
//Getters
string  Transferencia::getDatosBancarios(){
    return "***TRANSFERENCIA ELECTRONICA***\nBanco a transferir: " + banco + "\nReferencia de la cuenta: " + 
    referencia + "\nCuenta de origen: " + cuenta + "\nClabe de la cuenta: " + clabe;
 }
string Transferencia::getcomision(){
    return comision;
}